-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 06-10-2023 a las 05:29:57
-- Versión del servidor: 5.7.36
-- Versión de PHP: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `myteaponydb`
--
CREATE DATABASE IF NOT EXISTS `myteaponydb` DEFAULT CHARACTER SET utf16 COLLATE utf16_general_ci;
USE `myteaponydb`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `actividad`
--

DROP TABLE IF EXISTS `actividad`;
CREATE TABLE IF NOT EXISTS `actividad` (
  `idActividad` int(10) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `observaciones` text NOT NULL,
  PRIMARY KEY (`idActividad`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encargados`
--

DROP TABLE IF EXISTS `encargados`;
CREATE TABLE IF NOT EXISTS `encargados` (
  `correo` varchar(45) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `rol` varchar(15) NOT NULL,
  `institucion_idInstitucion` int(10) NOT NULL,
  PRIMARY KEY (`correo`),
  KEY `institucion_idInstitucion` (`institucion_idInstitucion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Volcado de datos para la tabla `encargados`
--

INSERT INTO `encargados` (`correo`, `nombre`, `pass`, `rol`, `institucion_idInstitucion`) VALUES
('Alanid', 'Alan', '$2a$08$SxjMveeuAzTy7rqVViQHiey7KHod5kY41tA7oslVA.1N7SJo.tsHO', 'Administrador', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `institucion`
--

DROP TABLE IF EXISTS `institucion`;
CREATE TABLE IF NOT EXISTS `institucion` (
  `idInstitución` int(10) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `municipio` varchar(50) NOT NULL,
  `estado` varchar(50) NOT NULL,
  PRIMARY KEY (`idInstitución`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf16;

--
-- Volcado de datos para la tabla `institucion`
--

INSERT INTO `institucion` (`idInstitución`, `nombre`, `municipio`, `estado`) VALUES
(1, 'CRIT - Michoacan', 'Morelia', 'Michoacán');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paciente`
--

DROP TABLE IF EXISTS `paciente`;
CREATE TABLE IF NOT EXISTS `paciente` (
  `karnet` int(10) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `fecha` date NOT NULL,
  `pass` varchar(50) NOT NULL,
  `encargados_correo` varchar(45) NOT NULL,
  `institucion_idInstitucion` int(10) NOT NULL,
  PRIMARY KEY (`karnet`),
  KEY `encargados_correo` (`encargados_correo`),
  KEY `institucion_idInstitucion` (`institucion_idInstitucion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `encargados`
--
ALTER TABLE `encargados`
  ADD CONSTRAINT `encargados_ibfk_1` FOREIGN KEY (`institucion_idInstitucion`) REFERENCES `institucion` (`idInstitución`);

--
-- Filtros para la tabla `paciente`
--
ALTER TABLE `paciente`
  ADD CONSTRAINT `paciente_ibfk_1` FOREIGN KEY (`encargados_correo`) REFERENCES `encargados` (`correo`),
  ADD CONSTRAINT `paciente_ibfk_2` FOREIGN KEY (`institucion_idInstitucion`) REFERENCES `institucion` (`idInstitución`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
