const bcryptjs = require('bcryptjs')
const conexion = require('../database/db')
const {promisify} = require('util')

//procedimiento para registrarnos
exports.register = async (req, res)=>{    
    try {
        const name = req.body.name
        const user = req.body.user
        const pass = req.body.pass
        let passHash = await bcryptjs.hash(pass, 8)    
        //console.log(passHash)   
        conexion.query('INSERT INTO encargados SET ?', {correo:user, nombre: name, pass:passHash}, (error, results)=>{
            if(error){console.log(error)}
            res.redirect('/')
        })
    } catch (error) {
        console.log(error)
    }       
}

exports.login = async (req, res)=>{
    if (req.session.authorized) {
        console.log("Hay sesion")
        res.redirect('/index.ejs')
    }else{
        try {
            const user = req.body.user
            const pass = req.body.pass        
    
            if(!user || !pass ){
                res.render('login',{
                    alert:true,
                    alertTitle: "Advertencia",
                    alertMessage: "Ingrese un usuario y password",
                    alertIcon:'info',
                    showConfirmButton: true,
                    timer: false,
                    ruta: 'login'
                })
            }else{
                conexion.query('SELECT * FROM encargados WHERE correo = ?', [user], async (error, results)=>{
                    if( results.length == 0 || ! (await bcryptjs.compare(pass, results[0].pass)) ){
                        res.render('login', {
                            alert: true,
                            alertTitle: "Error",
                            alertMessage: "Usuario y/o Password incorrectas",
                            alertIcon:'error',
                            showConfirmButton: true,
                            timer: false,
                            ruta: 'login'    
                        })
                    }else{
                        //inicio de sesión OK
                        const id = results[0].correo
                        conexion.query('SELECT * FROM encargados WHERE correo = ?', id, (error, results)=>{
                            if(results){
                                req.session.user = results[0];
                                req.session.authorized = true;
                                res.render('login', {
                                        alert: true,
                                        alertTitle: "Conexión exitosa",
                                        alertMessage: "¡LOGIN CORRECTO!",
                                        alertIcon:'success',
                                        showConfirmButton: false,
                                        timer: 800,
                                        ruta: ''
                                })
                            }
                        })
                    }
                })
            }
        } catch (error) {
            console.log(error)
        }
    }
}

exports.isAuthenticated = async (req, res, next)=>{
    if (req.session.authorized) {
        req.user = req.session.user
        return next()
    }else{
        res.redirect('/login')
    }
}

exports.logout = (req, res)=>{
    req.session.destroy();
    return res.redirect('/')
}